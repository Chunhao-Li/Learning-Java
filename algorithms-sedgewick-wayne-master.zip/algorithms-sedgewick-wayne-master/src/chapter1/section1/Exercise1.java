package chapter1.section1;

/**
 * Created by Rene Argento
 */
public class Exercise1 {

	public static void main(String[] args) {
		int resultA = (0 + 15) / 2;
		double resultB = 2.0e-6 * 100000000.1;
		boolean resultC = true && false || true && true;
		
		System.out.println("a) " + resultA);
		System.out.println("b) " + resultB);
		System.out.println("c) " + resultC);
	}

}
