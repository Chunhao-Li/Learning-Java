package chapter1.section1;

/**
 * Created by Rene Argento
 */
public class Exercise8 {

	public static void main(String[] args) {
		System.out.println('b');
		System.out.println('b' + 'c');
		System.out.println((char) ('a' + 4));
	}
	
}
